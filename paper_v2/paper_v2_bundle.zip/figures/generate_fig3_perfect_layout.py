import subprocess

latex_content = r"""\documentclass[tikz,border=2mm]{standalone}
\usepackage{tikz}
\usetikzlibrary{arrows.meta,positioning,shapes.geometric,fit,backgrounds,calc}
\usepackage{lmodern}

\begin{document}
\begin{tikzpicture}[
  >=Latex,
  font=\sffamily\scriptsize,
  % Panels
  tier_col/.style={draw=#1!70!black, fill=#1!2!white, rounded corners=6pt, line width=0.7pt},
  col_header/.style={fill=#1!14, draw=#1!70!black, line width=0.5pt, rounded corners=3pt, font=\bfseries\scriptsize, text=#1!95!black, inner sep=2.5pt, align=center},
  % Algorithmic Cards
  alg_card/.style={draw=#1!65!black, fill=white, rounded corners=4pt, line width=0.55pt, inner sep=3.5pt, align=left},
  % Decision Shape
  alg_decision/.style={draw=#1!85!black, fill=#1!10, rounded corners=3pt, line width=0.6pt, inner sep=2.5pt, font=\bfseries\scriptsize, text=#1!95!black, align=center},
  % Exit Shape
  alg_exit/.style={draw=green!70!black, fill=green!12, rounded corners=3pt, line width=0.65pt, inner sep=2.5pt, align=center, font=\bfseries\scriptsize, text=green!90!black},
  % Badges
  tag/.style={fill=#1!15, draw=#1!70!black, line width=0.35pt, rounded corners=1.5pt, inner sep=1.2pt, font=\bfseries\fontsize{4.2pt}{5.0pt}\selectfont, text=#1!95!black},
  % Arrows
  flow/.style={->, line width=0.95pt, draw=gray!70!black},
  flow_blue/.style={->, line width=0.95pt, draw=blue!75!black},
  flow_teal/.style={->, line width=0.95pt, draw=teal!80!black},
  flow_orange/.style={->, line width=1.05pt, draw=orange!85!black},
  flow_green/.style={->, line width=1.1pt, draw=green!65!black}
]

% ==========================================================
% BRAIN ICON MACRO (#1 = position, #2 = scale, #3 = color)
% ==========================================================
\def\drawbrain#1#2#3{
  \begin{scope}[shift={(#1)}, scale=#2]
    % Left hemisphere
    \draw[fill=#3!22, draw=#3!85!black, line width=0.65pt]
      (0, 0.72) 
      .. controls (-0.35, 0.82) and (-0.72, 0.62) .. (-0.72, 0.28)
      .. controls (-0.92, 0.12) and (-0.92, -0.22) .. (-0.68, -0.34)
      .. controls (-0.76, -0.58) and (-0.52, -0.78) .. (-0.28, -0.68)
      .. controls (-0.18, -0.82) and (-0.05, -0.68) .. (0, -0.58)
      -- cycle;
    % Right hemisphere
    \draw[fill=#3!22, draw=#3!85!black, line width=0.65pt]
      (0, 0.72) 
      .. controls (0.35, 0.82) and (0.72, 0.62) .. (0.72, 0.28)
      .. controls (0.92, 0.12) and (0.92, -0.22) .. (0.68, -0.34)
      .. controls (0.76, -0.58) and (0.52, -0.78) .. (0.28, -0.68)
      .. controls (0.18, -0.82) and (0.05, -0.68) .. (0, -0.58)
      -- cycle;
    % Midline
    \draw[#3!85!black, line width=0.65pt] (0, 0.70) -- (0, -0.56);
    % Neural nodes & synapses (Left)
    \fill[#3!85!black] (-0.32, 0.36) circle (0.9pt);
    \fill[#3!85!black] (-0.50, 0.02) circle (0.9pt);
    \fill[#3!85!black] (-0.22, -0.12) circle (0.9pt);
    \fill[#3!85!black] (-0.38, -0.42) circle (0.9pt);
    \draw[#3!65!black, line width=0.35pt] (-0.32, 0.36) -- (-0.50, 0.02) -- (-0.22, -0.12) -- (-0.38, -0.42);
    % Neural nodes & synapses (Right)
    \fill[#3!85!black] (0.32, 0.36) circle (0.9pt);
    \fill[#3!85!black] (0.50, 0.02) circle (0.9pt);
    \fill[#3!85!black] (0.22, -0.12) circle (0.9pt);
    \fill[#3!85!black] (0.38, -0.42) circle (0.9pt);
    \draw[#3!65!black, line width=0.35pt] (0.32, 0.36) -- (0.50, 0.02) -- (0.22, -0.12) -- (0.38, -0.42);
    % Synapse bridge
    \draw[#3!60!black, line width=0.35pt, dashed] (-0.22, -0.12) -- (0.22, -0.12);
  \end{scope}
}

% ==========================================================
% GEOMETRY:
% Total diagram width: 13.0cm
% Column 1 (Left): Center X = 3.0cm, Width = 5.8cm (X: 0.1 to 5.9)
% Center Gap: 1.2cm (X: 5.9 to 7.1, Center = 6.5cm)
% Column 2 (Right): Center X = 10.0cm, Width = 5.8cm (X: 7.1 to 12.9)
% Total Height: 7.0cm (Y: +3.5 to -3.5)
% ==========================================================

% ----------------------------------------------------------
% COLUMN 1: TIER 1 (INITIAL EVIDENCE REASONING & CLARITY AUDIT)
% ----------------------------------------------------------
\node[tier_col=blue, minimum width=5.8cm, minimum height=7.0cm] (col1) at (3.0, 0) {};
\node[col_header=blue, minimum width=5.5cm, anchor=north] (t1) at ([yshift=-1.8mm]col1.north) {
  Tier 1: Initial Evidence Reasoning \& Clarity Audit
};

% Step 1.1: Input Block (Uncompressed Graph)
\node[alg_card=blue, text width=5.1cm] (b1_in) at (3.0, 2.45) {
  \textbf{Input: Full Evidence Multigraph} \hfill \tikz{\node[tag=blue]{Unpruned $G_q$};}\\
  {\fontsize{4.8pt}{5.6pt}\selectfont
  $\bullet$ Complete multigraph: all retrieved rows \& connected passages\\
  $\bullet$ Guided path scaffold steers attention along linear graph structure\\
  $\bullet$ \textcolor{blue!90!black}{\textbf{Tied Candidates:}} \texttt{Toronto Eagles (1989)} vs \texttt{Toronto Blues (1989)}}
};

% Step 1.2: Process Block (Primary LLM Call with Brain Icon)
\node[alg_card=purple, fill=purple!4, text width=5.1cm] (b1_llm) at (3.0, 1.05) {
  \textbf{Step 1: Primary LLM Evaluation (Call 1)} \hfill \tikz{\drawbrain{0,0}{0.22}{purple};}\\
  {\fontsize{4.8pt}{5.6pt}\selectfont
  $\bullet$ Evaluates evidence path against question constraints\\
  $\bullet$ \textcolor{purple!90!black}{\textbf{Strict Audit Rule:}} Zero guessing on ambiguous candidate ties\\
  $\bullet$ Detects candidate collision on \texttt{formed=1989}; text bridge missing}
};

% Step 1.3: Decision Diamond / Box
\node[alg_decision=purple, text width=3.1cm] (b1_dec) at (2.05, -0.3) {
  Clarity Audit:\\
  Unambiguous?
};

% Branch 1: Fast Exit (Right inside Col 1)
\node[alg_exit, text width=1.55cm] (b1_exit) at (4.85, -0.3) {
  \textbf{Fast Exit}\\[-0.2mm]
  {\fontsize{4.4pt}{5.0pt}\selectfont $\approx 80\%$ Queries\\1 LLM Call}
};

% Step 1.4: Output Block (Diagnostic Handoff)
\node[alg_card=orange, fill=orange!4, draw=orange!75!black, text width=5.1cm] (b1_handoff) at (3.0, -2.15) {
  \textbf{Output: Diagnostic Handoff $\mathcal{D}$} \hfill \tikz{\node[tag=orange]{Collision Alert};}\\
  {\fontsize{4.8pt}{5.6pt}\selectfont
  $\bullet$ Two clubs match \texttt{formed = 1989}; \texttt{Blues} bridge doc is missing\\
  $\bullet$ Emits structured diagnostic packet $\mathcal{D}$ identifying competing rows\\
  $\bullet$ \textcolor{orange!90!black}{\textbf{Controlled Pause:}} Halts execution without hallucinated guess}
};

% Tier 1 Internal Connectors
\draw[flow_blue] (b1_in) -- (b1_llm);
\draw[flow] (b1_llm) -- (b1_dec);
\draw[flow_green] (b1_dec.east) -- (b1_exit.west);
\node[font=\bfseries\tiny, text=green!75!black, anchor=south] at ([yshift=0.5mm]$(b1_dec.east)!0.5!(b1_exit.west)$) {Yes};
\draw[flow_orange] (b1_dec.south) -- (b1_dec.south |- b1_handoff.north);
\node[font=\bfseries\tiny, text=orange!85!black, anchor=east] at ([xshift=-1mm]$(b1_dec.south)!0.5!(b1_dec.south |- b1_handoff.north)$) {No (Tied)};

% ----------------------------------------------------------
% CENTER TRANSITION: AUTOMATED BRIDGE & GRAPH COMPRESSION
% ----------------------------------------------------------
\node[draw=orange!80!black, fill=orange!7, rounded corners=3.5pt, line width=0.6pt, text width=1.45cm, align=center, inner sep=2.5pt] (bridge_box) at (6.5, -0.55) {
  \textbf{Bridge Search}\\[-0.2mm]
  {\fontsize{4.2pt}{5.0pt}\selectfont
  \textcolor{blue!90!black}{\textbf{Zero LLM Calls}}\\[0.6mm]
  $\bullet$ Fetch missing \texttt{Doc:Blues}\\[0.6mm]
  \textcolor{teal!90!black}{\textbf{Graph Compression:}}\\[0.3mm]
  Prune non-tied rows\\
  ($\approx 85\%$ size reduction)}
};

% Connecting wires
\draw[flow_orange, rounded corners=4pt] (b1_handoff.east) -- (6.5, -2.15) -- (bridge_box.south);
\draw[flow_teal, rounded corners=4pt] (bridge_box.north) -- (6.5, 2.45) -- (b2_in.west);
\node[tag=orange, fill=white] at (6.5, -2.45) {Handoff $\mathcal{D}$};
\node[tag=teal, fill=white] at (6.5, 2.75) {Capsule $\mathcal{S}_{\text{min}}$};

% ----------------------------------------------------------
% COLUMN 2: TIER 2 (TARGETED COLLISION RESOLUTION)
% ----------------------------------------------------------
\node[tier_col=teal, minimum width=5.8cm, minimum height=7.0cm] (col2) at (10.0, 0) {};
\node[col_header=teal, minimum width=5.5cm, anchor=north] (t2) at ([yshift=-1.8mm]col2.north) {
  Tier 2: Targeted Collision Resolution \& Verification
};

% Step 2.1: Input Minimal State Capsule (Compressed Graph)
\node[alg_card=teal, text width=5.1cm] (b2_in) at (10.0, 2.45) {
  \textbf{Input: Minimal State Capsule $\mathcal{S}_{\text{min}}$} \hfill \tikz{\node[tag=teal]{Compressed Graph};}\\
  {\fontsize{4.8pt}{5.6pt}\selectfont
  $\bullet$ \textcolor{teal!90!black}{\textbf{Graph Compression:}} Discards all non-competing candidate rows\\
  $\bullet$ Isolated context: contains strictly tied clubs + fetched bridge passage\\
  $\bullet$ Eliminates context dilution and prevents distracting interference}
};

% Step 2.2: Process Block (Targeted LLM Call with Brain Icon)
\node[alg_card=purple, fill=purple!4, text width=5.1cm] (b2_llm) at (10.0, 1.05) {
  \textbf{Step 2: Targeted LLM Resolution (Call 2)} \hfill \tikz{\drawbrain{0,0}{0.22}{purple};}\\
  {\fontsize{4.8pt}{5.6pt}\selectfont
  $\bullet$ Prompted exclusively with compressed minimal capsule $\mathcal{S}_{\text{min}}$\\
  $\bullet$ Evaluates tied candidates directly against factual bridge evidence\\
  $\bullet$ Verifies exact affiliation link: \texttt{Doc:Blues} links to \texttt{York University}}
};

% Step 2.3: Decision Diamond / Box
\node[alg_decision=teal, text width=4.8cm] (b2_dec) at (10.0, -0.3) {
  Factual Grounding: Verified by Bridge Doc?
};

% Step 2.4: Termination / Output Block
\node[alg_exit, fill=green!15, text width=5.1cm] (b2_final) at (10.0, -2.15) {
  \textbf{Termination: Final Verified Answer: ``York''}\\[0.5mm]
  {\fontsize{4.8pt}{5.6pt}\selectfont
  $\le 2$ LLM Calls Total $\bullet$ 100\% Grounded Provenance $\bullet$ Zero Hallucination\\[0.3mm]
  \textcolor{green!75!black}{Full audit trail: \texttt{Table Row 1} $\to$ \texttt{Doc:Toronto\_Blues} $\to$ \texttt{York}}}
};

% Tier 2 Internal Connectors
\draw[flow_teal] (b2_in) -- (b2_llm);
\draw[flow] (b2_llm) -- (b2_dec);
\draw[flow_green] (b2_dec.south) -- (b2_final.north);
\node[font=\bfseries\tiny, text=green!75!black, anchor=east] at ([xshift=-1mm]$(b2_dec.south)!0.5!(b2_final.north)$) {Yes (Grounded)};

\end{tikzpicture}
\end{document}
"""

with open("/workspace/kiennt/online-kg-rag/paper_v2/figures/generate_fig3_perfect_layout.tex", "w") as f:
    f.write(latex_content)

cmd = "pdflatex -interaction=nonstopmode generate_fig3_perfect_layout.tex && pdftoppm -png -r 150 generate_fig3_perfect_layout.pdf fig3_perf_out"
res = subprocess.run(cmd, shell=True, cwd="/workspace/kiennt/online-kg-rag/paper_v2/figures", capture_output=True, text=True)
print("Return code:", res.returncode)
